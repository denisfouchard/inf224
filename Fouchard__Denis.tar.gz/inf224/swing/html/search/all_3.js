var searchData=
[
  ['send_0',['send',['../class_client.html#ab26831c395da92b5893066f9ce7963a4',1,'Client']]],
  ['setcommandbuttons_1',['setCommandButtons',['../class_remote_control.html#aa097b65a6f45da0052d15c2ac4dcccce',1,'RemoteControl']]]
];
