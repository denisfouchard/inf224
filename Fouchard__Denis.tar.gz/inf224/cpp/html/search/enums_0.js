var searchData=
[
  ['errors_0',['Errors',['../class_socket.html#a9f68308228badcdd299cd83e62e36976',1,'Socket']]]
];
