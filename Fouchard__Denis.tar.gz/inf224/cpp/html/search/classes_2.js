var searchData=
[
  ['inputbuffer_0',['InputBuffer',['../struct_input_buffer.html',1,'']]]
];
