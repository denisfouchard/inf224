var indexSectionsWithContent =
{
  0: "abcdefgimprstvw~",
  1: "fgimpstv",
  2: "abcdgirstw~",
  3: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Enumerations"
};

