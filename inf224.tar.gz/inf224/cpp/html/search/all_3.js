var searchData=
[
  ['descriptor_0',['descriptor',['../class_socket.html#a1f3bad4217fea24f81d39f57406a0ec8',1,'Socket::descriptor()'],['../class_server_socket.html#a42fb2ded476612b5f23c46abb74db9c2',1,'ServerSocket::descriptor()']]]
];
