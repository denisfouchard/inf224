var searchData=
[
  ['client_0',['Client',['../class_client.html',1,'Client'],['../class_client.html#a163113b9c3fda23dcdc750db9278afbe',1,'Client.Client()']]],
  ['creategroup_1',['createGroup',['../class_media_selection_panel.html#a5d8fd9081c5be721df31efb55549916a',1,'MediaSelectionPanel']]]
];
